
// Fluxus Executor - Version 2 with Enhanced Features
const ffi = require('ffi-napi');
const ref = require('ref-napi');
const fs = require('fs');
const readline = require('readline');
const lua = require('lua-in-js').luaFactory;
const axios = require('axios'); 
const ps = require('ps-node'); 

class FluxusExecutor {
    constructor() {
        this.scriptHistory = [];
        this.luaRuntime = lua();
        this.cloudScriptURL = 'https://example.com/scripts'; 
    }

    displayMenu() {
        console.log(`
Fluxus Executor
====================
1. Inject DLL
2. Execute Lua Script
3. View Script History
4. Save Script History
5. Load Script History
6. Cloud Script Loader
7. Exit
====================
`);
    }

    validateDLLPath(path) {
        return fs.existsSync(path) && path.endsWith('.dll');
    }

    injectDLL() {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        rl.question('Enter path to DLL: ', (path) => {
            if (!this.validateDLLPath(path)) {
                console.error('Invalid DLL path. Make sure the file exists and is a .dll file.');
                rl.close();
                return;
            }

            console.log(`Attempting to inject DLL at ${path}`);

            const kernel32 = ffi.Library('kernel32', {
                'OpenProcess': ['pointer', ['uint32', 'bool', 'uint32']],
                'VirtualAllocEx': ['pointer', ['pointer', 'size_t', 'size_t', 'uint32']],
                'WriteProcessMemory': ['bool', ['pointer', 'pointer', 'pointer', 'size_t', 'pointer']],
                'CreateRemoteThread': ['pointer', ['pointer', 'pointer', 'size_t', 'pointer', 'pointer', 'uint32', 'pointer']],
                'CloseHandle': ['bool', ['pointer']]
            });

            const PROCESS_ALL_ACCESS = 0x1F0FFF;
            const MEM_COMMIT = 0x1000;
            const PAGE_READWRITE = 0x04;

            const robloxProcessId = this.getRobloxProcessId();
            if (!robloxProcessId) {
                console.error('Roblox process not found.');
                rl.close();
                return;
            }

            const hProcess = kernel32.OpenProcess(PROCESS_ALL_ACCESS, false, robloxProcessId);
            if (hProcess.isNull()) {
                console.error('Failed to open Roblox process.');
                rl.close();
                return;
            }

            const allocAddress = kernel32.VirtualAllocEx(hProcess, null, path.length + 1, MEM_COMMIT, PAGE_READWRITE);
            if (allocAddress.isNull()) {
                console.error('Failed to allocate memory in target process.');
                kernel32.CloseHandle(hProcess);
                rl.close();
                return;
            }

            const written = kernel32.WriteProcessMemory(hProcess, allocAddress, Buffer.from(path + '\0'), path.length + 1, null);
            if (!written) {
                console.error('Failed to write DLL path to target process memory.');
                kernel32.CloseHandle(hProcess);
                rl.close();
                return;
            }

            const loadLibraryAddr = ffi.Library('kernel32', { 'LoadLibraryA': ['pointer', ['string']] }).LoadLibraryA;
            const threadHandle = kernel32.CreateRemoteThread(hProcess, null, 0, loadLibraryAddr, allocAddress, 0, null);

            if (threadHandle.isNull()) {
                console.error('Failed to create remote thread in target process.');
                kernel32.CloseHandle(hProcess);
                rl.close();
                return;
            }

            console.log('DLL successfully injected.');
            kernel32.CloseHandle(threadHandle);
            kernel32.CloseHandle(hProcess);
            rl.close();
        });
    }

    getRobloxProcessId() {
        return new Promise((resolve, reject) => {
            ps.lookup({ command: 'RobloxPlayerBeta' }, (err, resultList) => {
                if (err) {
                    console.error(`Error retrieving Roblox process ID: ${err.message}`);
                    reject(null);
                }
                const robloxProcess = resultList.find(process => process);
                if (robloxProcess) {
                    resolve(parseInt(robloxProcess.pid));
                } else {
                    console.warn('Roblox process not found.');
                    resolve(null);
                }
            });
        });
    }

    executeLuaScript() {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        rl.question('Enter Lua script to execute: ', (script) => {
            try {
                if (!this.validateLuaScript(script)) {
                    throw new Error('Invalid Lua syntax.');
                }
                this.luaRuntime.execute(script);
                this.scriptHistory.push(script);
                console.log('Lua script executed successfully.');
            } catch (error) {
                console.error(`Error executing Lua script: ${error.message}`);
            }
            rl.close();
        });
    }

    validateLuaScript(script) {
        try {
            this.luaRuntime.compile(script);
            return true;
        } catch {
            return false;
        }
    }

    viewScriptHistory() {
        console.log('\nScript History:\n');
        this.scriptHistory.forEach((script, index) => {
            console.log(`${index + 1}: ${script}`);
        });
    }

    saveScriptHistory() {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        rl.question('Enter filename to save script history: ', (filename) => {
            fs.writeFile(filename, JSON.stringify(this.scriptHistory), (err) => {
                if (err) {
                    console.error(`Failed to save script history: ${err.message}`);
                } else {
                    console.log('Script history saved successfully.');
                }
            });
            rl.close();
        });
    }

    loadScriptHistory() {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        rl.question('Enter filename to load script history: ', (filename) => {
            fs.readFile(filename, 'utf8', (err, data) => {
                if (err) {
                    console.error(`Failed to load script history: ${err.message}`);
                } else {
                    try {
                        this.scriptHistory = JSON.parse(data);
                        console.log('Script history loaded successfully.');
                    } catch (parseError) {
                        console.error(`Error parsing script history: ${parseError.message}`);
                    }
                }
            });
            rl.close();
        });
    }

    loadCloudScript() {
        console.log('Fetching script from cloud storage...');
        axios.get(`${this.cloudScriptURL}/latest`).then((response) => {
            try {
                const script = response.data;
                console.log('Executing cloud script...');
                this.luaRuntime.execute(script);
                this.scriptHistory.push(script);
                console.log('Cloud script executed successfully.');
            } catch (error) {
                console.error(`Error executing cloud script: ${error.message}`);
            }
        }).catch((error) => {
            console.error(`Failed to load cloud script: ${error.message}`);
        });
    }

    run() {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        const handleUserInput = () => {
            this.displayMenu();
            rl.question('Choose an option: ', (option) => {
                switch (option) {
                    case '1':
                        this.injectDLL();
                        break;
                    case '2':
                        this.executeLuaScript();
                        break;
                    case '3':
                        this.viewScriptHistory();
                        break;
                    case '4':
                        this.saveScriptHistory();
                        break;
                    case '5':
                        this.loadScriptHistory();
                        break;
                    case '6':
                        this.loadCloudScript();
                        break;
                    case '7':
                        console.log('Exiting Fluxus Executor...');
                        rl.close();
                        return;
                    default:
                        console.log('Invalid choice. Try again.');
                }
                handleUserInput();
            });
        };

        handleUserInput();
    }
}

const executor = new FluxusExecutor();
executor.run();
