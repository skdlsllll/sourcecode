# JJSploit-executor

Because it is powered by the WeAreDevs Exploit API, JJSploit offers a near full Lua executor. JJSploit also features click teleport, ESP, speed, fly, infinite jump, and so much more. A powerful all in one package.

Instructions
Get going in just a few seconds!


Join a game
Make sure JJSploit is opened.
Click the large attach button on JJSploit.
Wait for the notification to appear at the bottom right of the game.

The notification means JJSploit is ready to use. You can now start executing scripts and using the button commands!

FAQ

Is this safe?

JJSploit was created by WeAreDevs, so you have our word that JJSploit is safe. Though anti-viruses will incorrectly flag JJSploit as malicious due to it's nature of exploitation. You will need to disable any anti-virus.

How long to wait for an update?

Because the games update every week, we need to update too. We strive to update ASAP, so usually within the hour or at least the same day. Sometimes there are complications and update times can take longer, but we will put a message on JJSploit if that happens. If you never get an update, then something is probably blocking the update from downloading. You may need to disable your anti-virus or use a VPN so JJSploit can automatically download the update.

Why won't this work with the Windows Store version of the game?

This was only made for the website version of the game engine. It will not work for the Windows Store version.

How can I report a new issue?

Please report bugs on the complaints forum found here: Complaints Forum Link

Is there a Discord server or any other support platform?

No, we do not offer an official server for game cheats. Instead, you can use the forum.

Help with it sometimes crashing on injection?

If you keep on crashing on injection, please close the game and wait 30 seconds before rejoining the game. This may take a few tries until it works. You may even need to try restarting your compute
