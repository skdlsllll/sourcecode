#pragma once
#include "Entity.h"
#include "Bones.h"
#include "UserCmd.h"
#include "Hooks.h"
#include "CheatMenu.h"
#include "Utils/Defines.h"

VOID SilentAim(CUserCmd* pCmd);
VOID Aimbot(CCSGOInput* Input);