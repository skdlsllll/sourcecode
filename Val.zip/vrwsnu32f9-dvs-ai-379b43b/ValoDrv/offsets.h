#pragma once

#include <ntddk.h>

namespace offsets
{
	uintptr_t shadow_region_offset = 0x83D98; //latest dump 11/18/24
}