#pragma once
#ifndef __VECTOR_H__
#define __VECTOR_H__

class Vector4 {
public:
	float x, y, z, w;
};
class Vector2 {
public:
	float x, y;

	inline Vector2() {
		x = y = 0.0f;
	}

	inline Vector2 operator/( float v ) const {
		return Vector2( x / v, y / v );
	}
	inline Vector2( float X, float Y ) {
		x = X; y = Y;
	}

	inline Vector2 operator-( const Vector2& v ) const {
		return Vector2( x - v.x, y - v.y );
	}

	inline Vector2 operator+( const Vector2& v ) const {
		return Vector2( x + v.x, y + v.y );
	}

	inline Vector2& operator+=( const Vector2& v ) {
		x += v.x; y += v.y; return *this;
	}

	inline bool Zero() const {
		return (x > -0.1f && x < 0.1f && y > -0.1f && y < 0.1f);
	}
};
class Vector3
{
public:
	float x, y, z;

public:
	bool W2S( Vector2& ScreenPos );

	float Magnitude()
	{
		return sqrt( this->x * this->x + this->y * this->y + this->z * this->z );
	}

	/* Used to normalize this vector */
	Vector3 Normalized()
	{
		/* Get the magnitude of this vector */
		float num = this->Magnitude();

		/* Check if number is more than max. */
		if (num > 9.99999974737875E-06)
		{
			return { this->x / num, this->y / num, this->z / num };
		}

		/* Return an empty vector */
		return Vector3();
	}

	inline Vector3() {
		x = y = z = 0.0f;
	}

	inline Vector3( float X, float Y, float Z ) {
		x = X; y = Y; z = Z;
	}

	inline float operator[]( int i ) const {
		return ((float*)this)[ i ];
	}

	inline Vector3& operator-=( float v ) {
		x -= v; y -= v; z -= v; return *this;
	}

	inline Vector3 operator*( float v ) const {
		return Vector3( x * v, y * v, z * v );
	}

	inline Vector3 operator/( float v ) const
	{
		return Vector3( x / v, y / v, z / v );
	}

	inline Vector3& operator+=( const Vector3& v ) {
		x += v.x; y += v.y; z += v.z; return *this;
	}

	inline Vector3 operator-( const Vector3& v ) const {
		return Vector3( x - v.x, y - v.y, z - v.z );
	}

	inline Vector3 operator+( const Vector3& v ) const {
		return Vector3( x + v.x, y + v.y, z + v.z );
	}

	inline float Length() {
		return sqrtf( x * x + y * y + z * z );
	}
};

struct Matrix3x4
{
	Vector4 vec0;
	Vector4 vec1;
	Vector4 vec2;
};
struct Matrix4x4 {
	union {
		struct {
			float        _11, _12, _13, _14;
			float        _21, _22, _23, _24;
			float        _31, _32, _33, _34;
			float        _41, _42, _43, _44;

		}; float m[ 4 ][ 4 ];
	};
};
struct TransformAccessReadOnly
{
	uint64_t pTransformData;
};
struct TransformData
{
	uint64_t pTransformArray;
	uint64_t pTransformIndices;
};

namespace Math
{
#define M_PI 3.14159265358979323846f
#define M_RADPI	57.295779513082f
#define M_PI_F ((float)(M_PI))
#define RAD2DEG(x) ((float)(x) * (float)(180.f / M_PI_F))
#define DEG2RAD(x) ((float)(x) * (float)(M_PI_F / 180.f))
#define atan2(a, b) ((float)atan2((double)(a), (double)(b)))

	static volatile const double Infinity = INFINITY;
	typedef struct { double d0, d1; } double2;

	static inline double2 Add212RightSmaller( double2 a, double b )
	{
		double
			c0 = a.d0 + b,
			c1 = a.d0 - c0 + b + a.d1,
			d0 = c0 + c1,
			d1 = c0 - d0 + c1;
		return double2 { d0, d1 };
	}

	static inline double Add221RightSmaller( double2 a, double2 b )
	{
		double
			c0 = a.d0 + b.d0,
			c1 = a.d0 - c0 + b.d0 + b.d1 + a.d1,
			d0 = c0 + c1;
		return d0;
	}

	//float abs( float a ) {
	//	if (a < 0.f) return -a;
	//	else return a;
	//}
	//
	//float asin( float x ) {
	//	float negate = float( x < 0 );
	//	x = abs( x );
	//	float ret = -0.0187293;
	//	ret *= x;
	//	ret += 0.0742610;
	//	ret *= x;
	//	ret -= 0.2121144;
	//	ret *= x;
	//	ret += 1.5707288;
	//	ret = 3.14159265358979 * 0.5 - sqrt( 1.0 - x ) * ret;
	//	return ret - 2 * negate * ret;
	//}

	__forceinline float Dot( const Vector3& Vec1, const Vector3& Vec2 ) {
		return Vec1[ 0 ] * Vec2[ 0 ] + Vec1[ 1 ] * Vec2[ 1 ] + Vec1[ 2 ] * Vec2[ 2 ];
	}

	__forceinline float Calc3D_Dist( const Vector3& Src, const Vector3& Dst ) {
		return sqrtf( pow( (Src.x - Dst.x), 2 ) + pow( (Src.y - Dst.y), 2 ) + pow( (Src.z - Dst.z), 2 ) );
	}

	__forceinline float Calc2D_Dist( const Vector2& Src, const Vector2& Dst ) {
		return sqrt( powf( Src.x - Dst.x, 2 ) + powf( Src.y - Dst.y, 2 ) );
	}

	__forceinline Vector2 CalcAngle( const Vector3& Src, const Vector3& Dst ) {
		Vector3 dir = Src - Dst;
		return Vector2 { RAD2DEG( asin( dir.y / dir.Length() ) ), RAD2DEG( -atan2( dir.x, -dir.z ) ) };
	}

}

#endif